from OurCode5 import runpatternAlgo




runpatternAlgo()
